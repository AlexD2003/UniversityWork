#include "Entity.h"
#include "EntityType.h"
#include <algorithm> // for std::fill

void Entity::demographics(unsigned int population[], const SimulationGrid& g)
{
	// set the population array to 0
	std::fill(population, population + 8, 0);

	int dx[]{0, 0, 1, 1, 1, -1, -1, -1};
	int dy[]{1, -1, -1, 0, 1,  -1, 0, 1};

	unsigned int neigh{ sizeof(dy) / sizeof(dy[0]) };
	
	for (unsigned int i{ 0 }; i < neigh; ++i) {
		int r{ row + dy[i] };
		int c{ col + dx[i] };
		if (r >= 0 && r < MAX_COLS && c >= 0 && c < MAX_COLS) {
			EntityType et = g.m_grid[r][c]->what();
			// convert the enum class to int
			population[to_underlying(et)]++;
		}
	}
	
}

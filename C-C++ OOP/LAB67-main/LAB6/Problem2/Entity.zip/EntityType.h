#pragma once
#include <type_traits>
// Create an enum class called EntityType with the following values : EMPTY, FOX, GOPHER, PLANT

enum class EntityType {
    EMPTY = 0,
    // TODO your code here
};


template <typename E>
constexpr auto to_underlying(E e) 
{
    return static_cast<std::underlying_type_t<E>>(e);
}